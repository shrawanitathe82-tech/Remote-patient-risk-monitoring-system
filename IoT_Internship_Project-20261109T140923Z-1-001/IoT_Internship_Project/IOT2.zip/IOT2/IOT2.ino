#include <WiFi.h>
#include "Adafruit_MQTT.h"
#include "Adafruit_MQTT_Client.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// --- Configuration ---
#define WLAN_SSID       "Wokwi-GUEST" // Standard Wokwi virtual WiFi SSID
#define WLAN_PASS       ""            // No password required for Wokwi-GUEST
#define AIO_SERVER      "io.adafruit.com"
#define AIO_SERVERPORT  1883
#define AIO_USERNAME    "raj13"
#define AIO_KEY         "aio_ffsh65CIq5akdiZtqKuNDqCBWRZK" 

// --- Hardware Pins ---
#define LED_PIN        13
#define BUZZER_PIN     12
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT  64
#define OLED_RESET     -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- System State Variables ---
float targetDosage = 0.0;   // The value requested by the doctor via the slider
float currentDosage = 0.0;  // The actual rate-limited dosage being administered
const float MAX_RATE_CHANGE = 2.0; // Maximum mg/hr dosage adjustment per loop cycle

unsigned long lastBlinkTime = 0;
bool ledState = false;

// --- MQTT Client & Feed Setup ---
WiFiClient client;
Adafruit_MQTT_Client mqtt(&client, AIO_SERVER, AIO_SERVERPORT, AIO_USERNAME, AIO_KEY);

// Subscribe to the slider feed to receive instructions
Adafruit_MQTT_Subscribe dosage_subscribe = Adafruit_MQTT_Subscribe(&mqtt, AIO_USERNAME "/feeds/dosage-control");
// Publish to the status feed to send real-time data back to the dashboard
Adafruit_MQTT_Publish dosage_publish = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/dosage-status");

// Function prototype for robust connection management
void MQTT_connect();

void setup() {
  Serial.begin(115200);
  
  // Initialize Hardware Pins
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Initialize SSD1306 OLED Display
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println(F("OLED allocation failed! Check your I2C wiring."));
    for(;;);
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  
  // Establish WiFi Connection
  Serial.print("Connecting to WiFi");
  display.setTextSize(1);
  display.setCursor(0,0);
  display.print("Connecting WiFi...");
  display.display();
  
  WiFi.begin(WLAN_SSID, WLAN_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected!");

  // Register MQTT Subscriptions
  mqtt.subscribe(&dosage_subscribe);
}

void loop() {
  // Ensure we stay connected to Adafruit IO
  MQTT_connect();

  // 1. Process Incoming Dashboard Slider Signals
  Adafruit_MQTT_Subscribe *subscription;
  while ((subscription = mqtt.readSubscription(50))) {
    if (subscription == &dosage_subscribe) {
      float newTarget = atof((char *)dosage_subscribe.lastread);
      
      // Safety confirmation logs in terminal for abrupt changes
      if (newTarget > 80.0 && currentDosage < 50.0) {
        Serial.println("ALERT: Abrupt critical dosage jump requested by dashboard!");
      }
      
      targetDosage = newTarget;
      Serial.print("New target dosage updated to: ");
      Serial.print(targetDosage);
      Serial.println(" mg/hr");
    }
  }

  // 2. Rate-Limiting Logic (Prevents sudden dangerous spikes)
  if (currentDosage < targetDosage) {
    currentDosage += min(MAX_RATE_CHANGE, targetDosage - currentDosage);
  } else if (currentDosage > targetDosage) {
    currentDosage -= min(MAX_RATE_CHANGE, currentDosage - targetDosage);
  }

  // 3. Safety Threshold Monitoring & Emergency System
  String safetyStatus = "NORMAL";
  
  if (currentDosage > 80.0) {
    safetyStatus = "CRITICAL";
    // Non-blocking rapid asynchronous blink & buzz pattern
    if (millis() - lastBlinkTime >= 150) { 
      lastBlinkTime = millis();
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState);
      if (ledState) {
        tone(BUZZER_PIN, 1000); // Trigger 1kHz safety alarm sound
      } else {
        noTone(BUZZER_PIN);
      }
    }
  } else if (currentDosage > 50.0 && currentDosage <= 80.0) {
    safetyStatus = "WARNING";
    digitalWrite(LED_PIN, HIGH); // Solid warning indicator light
    noTone(BUZZER_PIN);          // No sound during warning state
  } else {
    safetyStatus = "NORMAL";
    digitalWrite(LED_PIN, LOW);   // Safe state indicators cleared
    noTone(BUZZER_PIN);
  }

  // 4. Update the Patient-Side OLED Monitor
  display.clearDisplay();
  
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("SAFETY: ");
  display.print(safetyStatus);
  
  display.setCursor(0, 16);
  display.print("Target Rx: ");
  display.print(targetDosage, 1);
  display.print(" mg/h");

  // Bold layout accentuating the current delivered rate
  display.setTextSize(2);
  display.setCursor(0, 35);
  display.print(currentDosage, 1);
  display.setTextSize(1);
  display.print(" mg/hr");
  
  display.display();

  // 5. Throttled Telemetry Feedback Loop back to Adafruit IO Dashboard
  static unsigned long lastPublishTime = 0;
  if (millis() - lastPublishTime > 3000) { // Publishes every 3 seconds to stay well below API limits
    lastPublishTime = millis();
    dosage_publish.publish(currentDosage);
  }

  delay(50); // Small cycle delay to steady system performance
}

// Robust, self-healing connection handler for Adafruit MQTT services
void MQTT_connect() {
  int8_t ret;
  if (mqtt.connected()) {
    return;
  }

  Serial.print("Connecting to Adafruit IO MQTT... ");
  uint8_t retries = 3;
  while ((ret = mqtt.connect()) != 0) { 
       Serial.println(mqtt.connectErrorString(ret));
       Serial.println("Retrying connection in 5 seconds...");
       mqtt.disconnect();
       delay(5000); 
       retries--;
       if (retries == 0) {
         Serial.println("Connection failed permanently. Halting firmware loop.");
         while (1); 
       }
  }
  Serial.println("MQTT Connection Successfully Established!");
}