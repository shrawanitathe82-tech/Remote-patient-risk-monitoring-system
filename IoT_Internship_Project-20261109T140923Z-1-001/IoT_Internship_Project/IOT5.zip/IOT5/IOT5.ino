#include <WiFi.h>
#include <Adafruit_MQTT.h>
#include <Adafruit_MQTT_Client.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include "SPIFFS.h"

// --- Credentials ---
#define WLAN_SSID       "Wokwi-GUEST"
#define WLAN_PASS       ""
#define AIO_SERVER      "io.adafruit.com"
#define AIO_SERVERPORT  1883
#define AIO_USERNAME    "raj13"
#define AIO_KEY         "aio_ffsh65CIq5akdiZtqKuNDqCBWRZK"

// --- Pins ---
#define DHTPIN 15
#define BUZZER 13
#define LED_GREEN 25
#define LED_YELLOW 26
#define LED_RED 27

DHT dht(DHTPIN, DHT22);
Adafruit_SSD1306 display(128, 64, &Wire, -1);
WiFiClient client;
Adafruit_MQTT_Client mqtt(&client, AIO_SERVER, AIO_SERVERPORT, AIO_USERNAME, AIO_KEY);

// --- Feeds ---
Adafruit_MQTT_Publish tempFeed = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temperature");
Adafruit_MQTT_Publish statusFeed = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/system-status");
Adafruit_MQTT_Publish bufferFeed = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/buffer-count");

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER, OUTPUT);
  pinMode(LED_GREEN, OUTPUT); pinMode(LED_YELLOW, OUTPUT); pinMode(LED_RED, OUTPUT);

  if(!SPIFFS.begin(true)) Serial.println("SPIFFS Mount Failed");
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  dht.begin();
  
  WiFi.begin(WLAN_SSID, WLAN_PASS);
}

void loop() {
  float temp = dht.readTemperature();
  int rssi = WiFi.RSSI();
  String status = "ONLINE";

  if (WiFi.status() == WL_CONNECTED) {
    if (!mqtt.connected()) mqtt.connect();
    
    // Check for DEGRADED state (Signal < -70dBm)
    if (rssi < -70) status = "DEGRADED";

    digitalWrite(LED_GREEN, (status == "ONLINE") ? HIGH : LOW);
    digitalWrite(LED_YELLOW, (status == "DEGRADED") ? HIGH : LOW);
    digitalWrite(LED_RED, LOW);
    
    tempFeed.publish((double)temp);
    statusFeed.publish(status.c_str());
    bufferFeed.publish((int32_t)0);
    
    syncBufferedData();
  } else {
    status = "OFFLINE";
    digitalWrite(LED_GREEN, LOW); digitalWrite(LED_YELLOW, LOW); digitalWrite(LED_RED, HIGH);
    tone(BUZZER, 1000, 200);
    
    File file = SPIFFS.open("/data.txt", FILE_APPEND);
    if(file) { file.println(temp); file.close(); }
    
    bufferFeed.publish((int32_t)countBufferedRecords());
  }
  
  updateOLED(status, temp, rssi);
  delay(5000);
}

int countBufferedRecords() {
  int count = 0;
  if (SPIFFS.exists("/data.txt")) {
    File file = SPIFFS.open("/data.txt", "r");
    while (file.available()) {
      if (file.readStringUntil('\n') != "") count++;
    }
    file.close();
  }
  return count;
}

void syncBufferedData() {
  if (!SPIFFS.exists("/data.txt")) return;
  
  File file = SPIFFS.open("/data.txt", "r");
  while (file.available()) {
    String line = file.readStringUntil('\n');
    if (mqtt.connected() && tempFeed.publish((double)line.toFloat())) {
      Serial.println("Synced: " + line);
    }
  }
  file.close();
  SPIFFS.remove("/data.txt");
  bufferFeed.publish((int32_t)0);
}

void updateOLED(String status, float temp, int rssi) {
  display.clearDisplay();
  display.setTextSize(1); display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.println("STATE: " + status);
  display.print("Temp:  "); display.print(temp); display.println(" C");
  display.print("Buffer: "); display.print(countBufferedRecords()); display.println(" logs");
  display.print("Signal: "); display.print(rssi); display.println(" dBm");
  display.display();
}